#!/bin/bash

echo "🔧 Nexus 多节点部署初始化（共 4 个节点，可视分屏）"

if ! command -v tmux &> /dev/null; then
  echo "📦 安装 tmux..."
  sudo apt update && sudo apt install -y tmux
fi

if ! command -v nexus-network &> /dev/null; then
  echo "🌐 安装 nexus-network CLI..."
  curl https://cli.nexus.xyz/ | sh
  export PATH="$HOME/.nexus/bin:$PATH"
fi

echo "📥 请依次输入 4 个 Node ID（每行一个）："
NODE_IDS=()
for i in $(seq -w 1 4); do
  read -p "Node $i ID: " ID
  NODE_IDS+=("$ID")
done

mkdir -p ~/nexus_nodes
for i in $(seq -w 1 4); do
  ID=${NODE_IDS[$((10#$i - 1))]}
  NODE_DIR=~/nexus_nodes/node$i
  mkdir -p "$NODE_DIR/.nexus"
  echo "{ \"node_id\": \"$ID\" }" > "$NODE_DIR/.nexus/config.json"
  echo -e "#!/bin/bash\nexport HOME=$(pwd)\nmkdir -p \$HOME/.nexus\ncp \$HOME/.nexus/config.json \$HOME/.nexus/config.json\nexec nexus-network start --env beta" > "$NODE_DIR/start.sh"
  chmod +x "$NODE_DIR/start.sh"
done

SESSION="nexus-4nodes"
tmux kill-session -t $SESSION 2>/dev/null

tmux new-session -d -s $SESSION -n page1 "cd ~/nexus_nodes/node01 && ./start.sh"
tmux split-window -t $SESSION:0 -v "cd ~/nexus_nodes/node02 && ./start.sh"
tmux split-window -t $SESSION:0 -h "cd ~/nexus_nodes/node03 && ./start.sh"
tmux select-pane -t $SESSION:0.1
tmux split-window -t $SESSION:0 -h "cd ~/nexus_nodes/node04 && ./start.sh"

tmux select-layout -t $SESSION:0 tiled

echo "✅ 4 个节点已启动，并可视化分屏完成"
echo "🖥️ 使用命令查看：tmux attach -t nexus-4nodes"
echo "🧭 使用 Ctrl+b → 方向键 切换窗口，Ctrl+b → d 退出"
