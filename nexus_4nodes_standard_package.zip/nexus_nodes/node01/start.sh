#!/bin/bash
export HOME=$(pwd)
nexus-network start --env beta
