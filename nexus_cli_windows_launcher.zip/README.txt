📘 Nexus CLI Node 一键安装包（带图标启动）

【使用方法】
1. 解压此压缩包
2. 将 install_nexus_cli_node.sh 和 Run_Nexus_Installer.bat 放入 Windows 下载目录
3. 双击 Run_Nexus_Installer.bat 即可在 WSL 中自动运行脚本

【前提要求】
- 安装好 Windows Subsystem for Linux (WSL)
- WSL 中已有 Ubuntu

脚本将自动完成依赖安装、Node ID 配置，并以 tmux 分屏启动 4 个节点。
