#!/bin/bash
set -e
echo "🔧 正在部署 Nexus CLI 节点..."

sudo apt update && sudo apt install -y curl build-essential pkg-config libssl-dev git-all tmux protobuf-compiler

if ! command -v rustc &> /dev/null; then
  curl https://sh.rustup.rs -sSf | sh -s -- -y
  source "$HOME/.cargo/env"
fi

rustup target add riscv32i-unknown-none-elf

if ! command -v nexus-network &> /dev/null; then
  curl https://cli.nexus.xyz/ | sh
  export PATH="$HOME/.nexus/bin:$PATH"
fi

echo "📥 请输入 4 个 Node ID："
NODE_IDS=()
for i in $(seq -w 1 4); do
  read -p "Node $i ID: " ID
  NODE_IDS+=("$ID")
done

mkdir -p ~/nexus_nodes
for i in $(seq -w 1 4); do
  ID=${NODE_IDS[$((10#$i - 1))]}
  DIR=~/nexus_nodes/node$i
  mkdir -p "$DIR/.nexus"
  echo "{ \"node_id\": \"$ID\" }" > "$DIR/.nexus/config.json"
  cat >"$DIR/start.sh" <<EOF
#!/bin/bash
export HOME=\$(pwd)
mkdir -p \$HOME/.nexus
cp \$HOME/.nexus/config.json \$HOME/.nexus/config.json
exec nexus-network start --env beta
EOF
  chmod +x "$DIR/start.sh"
done

SESSION="nexus-4nodes"
tmux kill-session -t $SESSION 2>/dev/null
tmux new-session -d -s $SESSION -n main "cd ~/nexus_nodes/node01 && ./start.sh"
tmux split-window -t $SESSION:0 -v "cd ~/nexus_nodes/node02 && ./start.sh"
tmux split-window -t $SESSION:0 -h "cd ~/nexus_nodes/node03 && ./start.sh"
tmux select-pane -t $SESSION:0.1
tmux split-window -t $SESSION:0 -h "cd ~/nexus_nodes/node04 && ./start.sh"
tmux select-layout -t $SESSION:0 tiled

echo "✅ 已启动 4 个节点，使用 tmux attach -t nexus-4nodes 查看"
