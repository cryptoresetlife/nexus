📘 Nexus CLI 节点安装器（默认启动 Ubuntu）

【使用方法】
1. 解压此压缩包
2. 将 install_nexus_cli_node.sh 和 Run_Nexus_Installer.bat 放入 Windows 下载目录
3. 双击 Run_Nexus_Installer.bat 将打开 Ubuntu 并执行安装脚本

【要求】
- WSL 中已安装 Ubuntu（默认名称为 "Ubuntu"）
- 若为 Ubuntu-20.04 或 Ubuntu-22.04，请手动修改 .bat 文件中 "-d Ubuntu"

【效果】
脚本将自动完成依赖安装、节点配置，并以 tmux 分屏运行 4 个节点。
