#!/bin/bash

echo "🔧 Nexus 多节点分页部署初始化（每页 4 个节点，共 5 页）"

# 安装依赖
if ! command -v tmux &> /dev/null; then
  echo "📦 安装 tmux..."
  sudo apt update && sudo apt install -y tmux
fi

if ! command -v nexus-network &> /dev/null; then
  echo "🌐 安装 nexus-network CLI..."
  curl https://cli.nexus.xyz/ | sh
  export PATH="$HOME/.nexus/bin:$PATH"
fi

echo "📥 请输入 20 个 Node ID（每行一个），粘贴后按 Ctrl+D 结束："
NODE_IDS=()
while IFS= read -r line || [[ -n "$line" ]]; do
  NODE_IDS+=("$line")
done

if [ "${#NODE_IDS[@]}" -ne 20 ]; then
  echo "❌ 必须恰好输入 20 个 Node ID，实际输入了 ${#NODE_IDS[@]} 个。"
  exit 1
fi

mkdir -p ~/nexus_nodes
for i in $(seq -w 1 20); do
  ID=${NODE_IDS[$((10#$i - 1))]}
  NODE_DIR=~/nexus_nodes/node$i
  mkdir -p "$NODE_DIR/.nexus"

  echo "{ \"node_id\": \"$ID\" }" > "$NODE_DIR/.nexus/config.json"

  cat <<EOF > "$NODE_DIR/start.sh"
#!/bin/bash
export HOME=\$(pwd)
nexus-network start
EOF
  chmod +x "$NODE_DIR/start.sh"
done

SESSION="nexus-paged"
tmux kill-session -t $SESSION 2>/dev/null

# 每 4 个节点作为一个窗口，分屏显示，共 5 页
for PAGE in $(seq 0 4); do
  WIN="page$((PAGE+1))"
  IDX_START=$((PAGE * 4 + 1))
  IDX_END=$((IDX_START + 3))

  tmux new-session -d -s $SESSION -n "$WIN" "cd ~/nexus_nodes/node$(printf '%02d' $IDX_START) && ./start.sh"

  for j in $(seq 1 3); do
    IDX=$((IDX_START + j))
    if [ $IDX -le 20 ]; then
      tmux split-window -t $SESSION:$PAGE -v "cd ~/nexus_nodes/node$(printf '%02d' $IDX) && ./start.sh"
    fi
  done

  tmux select-layout -t $SESSION:$PAGE tiled
done

echo "✅ 所有 20 个节点已分页启动（每页显示 4 个）"
echo "🖥️ 使用命令查看：tmux attach -t nexus-paged"
echo "➡️ 在 tmux 中使用 Ctrl+b → n/p 切换分页窗口"
