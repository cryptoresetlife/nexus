#!/bin/bash
set -e

echo "🔧 开始部署 Nexus CLI 单节点（Devnet 模式）"

# 1. 安装依赖
sudo apt update && sudo apt install -y curl build-essential pkg-config libssl-dev git tmux protobuf-compiler

# 2. 安装 Rust（如果没安装）
if ! command -v rustc &>/dev/null; then
  echo "🦀 安装 Rust..."
  curl https://sh.rustup.rs -sSf | sh -s -- -y
  source "$HOME/.cargo/env"
fi

rustup target add riscv32i-unknown-none-elf

# 3. 安装 Nexus CLI（如果没安装）
if ! command -v nexus-network &>/dev/null; then
  echo "🌐 安装 Nexus CLI..."
  curl https://cli.nexus.xyz/ | sh
fi
export PATH="$HOME/.nexus/bin:$PATH"

# 4. 读取节点 ID
read -p "📥 请输入 Node ID: " NODE_ID

# 5. 创建节点目录和配置
NODE_DIR="$HOME/nexus_nodes/node01"
mkdir -p "$NODE_DIR/.nexus"
echo "{\"node_id\": \"$NODE_ID\"}" > "$NODE_DIR/.nexus/config.json"

# 6. 启动节点
echo "▶️ 启动节点，日志将输出到当前终端"
HOME="$NODE_DIR" nexus-network start --env beta
